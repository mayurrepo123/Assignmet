import { Component, OnInit } from '@angular/core';
import {WeatherService} from '../weather.service';

@Component({
  selector: 'app-weather-list',
  templateUrl: './weather-list.component.html',
  styleUrls: ['./weather-list.component.css']
})
export class WeatherListComponent implements OnInit {

  constructor(private weather_service : WeatherService) { }

  cityData=[];
  errorMsg: string;
  selectedCity: string;
  cityWeatherData: any;
  clr=['#ffc107','#f86c6b','#63c2de','#4dbd74','#20a8d8'];
  ngOnInit(){
console.log('ts call');
    this.weather_service.getCityWeather().subscribe(data => {
      this.cityData = data['list']
      console.log('weather',data['list']);
    }, error => this.errorMsg = <any>error);
  }


  getWeatherData(cityName: string) {
    this.weather_service.getWeatherDetails(cityName)
      .subscribe(data => {
        this.cityWeatherData = data['list'];
        console.log('City weather',data['list']);
      }, error => this.errorMsg = <any>error);

  }


}
