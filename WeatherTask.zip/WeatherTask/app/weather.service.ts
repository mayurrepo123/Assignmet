import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  constructor(private http:HttpClient) { }

  appId = "3d8b309701a13f65b660fa2c64cdc517";
  baseUrl = "http://api.openweathermap.org/data/2.5/";

  getCityWeather(){console.log('service call');
    return this.http.get(this.baseUrl +'group?id=4180386,4717560,4192205,4219762,2759794&appid='+ this.appId);
  }

  getWeatherDetails(cityName: string) {

    return this.http.get(
    this.baseUrl +
    'forecast?q=' + cityName +
    '&appid=' + this.appId
  )

  }
}
