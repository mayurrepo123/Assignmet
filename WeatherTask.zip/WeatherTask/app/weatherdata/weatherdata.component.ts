import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-weatherdata',
  templateUrl: './weatherdata.component.html',
  styleUrls: ['./weatherdata.component.css']
})
export class WeatherdataComponent implements OnInit {
  @Input('weatherForecastList') weathers: any;
  constructor() { }

  ngOnInit(): void {
  }

}
